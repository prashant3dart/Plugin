import bpy

class OBJECT_OT_align_objects(bpy.types.Operator):
    bl_idname = "object.align_objects_axis"
    bl_label = "Align Objects Along Axis"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        name="Axis",
        items=[('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")],
        default='X'
    )
    spacing: bpy.props.FloatProperty(
        name="Spacing",
        default=2.0,
        min=0.0
    )

    def execute(self, context):
        objects = context.selected_objects
        objects.sort(key=lambda obj: obj.name)
        for i, obj in enumerate(objects):
            if self.axis == 'X':
                obj.location.x = i * self.spacing
            elif self.axis == 'Y':
                obj.location.y = i * self.spacing
            elif self.axis == 'Z':
                obj.location.z = i * self.spacing
        return {'FINISHED'}

class OBJECT_PT_align_objects_panel(bpy.types.Panel):
    bl_label = "Align Objects"
    bl_idname = "OBJECT_PT_align_objects"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Align'

    def draw(self, context):
        layout = self.layout
        layout.operator("object.align_objects_axis")

def register():
    bpy.utils.register_class(OBJECT_OT_align_objects)
    bpy.utils.register_class(OBJECT_PT_align_objects_panel)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_align_objects)
    bpy.utils.unregister_class(OBJECT_PT_align_objects_panel)

if __name__ == "__main__":
    register()
