bl_info = {
    "name": "Remove Materials",
    "author": "Meet & Tech Boy JaTiX", 
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > JaTiX Tools", 
    "description": "Remove all materials and slots", 
    "warning": "",
    "doc_url": "",
    "category": "Materials", 
}

import bpy

class RemoveMaterialsOperator(bpy.types.Operator):
    bl_idname = "object.remove_materials"
    bl_label = "Remove All Materials"
    bl_description = "Remove all materials and slots from mesh objects"

    def execute(self, context):
        # Iterate through all objects in the scene
        for obj in bpy.data.objects:
            if obj.type == 'MESH':  # Ensure we're dealing with mesh objects
                # Clear all material slots from the object
                obj.data.materials.clear()

        # Now remove all materials from the material list
        for material in bpy.data.materials:
            print(f"Removing material: {material.name}")
            bpy.data.materials.remove(material)

        return {'FINISHED'}


class JaTiXToolsPanel(bpy.types.Panel):
    bl_label = "JaTiX Tools"
    bl_idname = "OBJECT_PT_jatix_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'

    def draw(self, context):
        layout = self.layout
        layout.operator(RemoveMaterialsOperator.bl_idname)


def register():
    bpy.utils.register_class(RemoveMaterialsOperator)
    bpy.utils.register_class(JaTiXToolsPanel)


def unregister():
    bpy.utils.unregister_class(RemoveMaterialsOperator)
    bpy.utils.unregister_class(JaTiXToolsPanel)


if __name__ == "__main__":
    register()