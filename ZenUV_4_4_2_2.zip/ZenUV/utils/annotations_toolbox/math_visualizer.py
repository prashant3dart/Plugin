# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Copyright 2023, Alex Zhornyak, Valeriy Yatsenko

import bpy
import json
import math
from mathutils import Vector, Color, Matrix

from .shapes import AnnotationShapes


class TextFactory:

    letters_dict = dict()

    @classmethod
    def format_entry(cls, key, value, split_by: int = 2):
        """ format a dictionary entry """
        # Format the numeric values
        formatted_values = ',\n    '.join(str(v) if isinstance(v, float) else repr(v) for v in value[:2])

        # Format the list with two elements per row
        list_values = value[2]
        formatted_list = ',\n        '.join(', '.join(map(repr, list_values[i:i+split_by])) for i in range(0, len(list_values), split_by))

        return f"{key} = [\n    {formatted_values},\n    [\n        {formatted_list}\n    ]\n]"

    @classmethod
    def read_json_font(cls, json_font_name: str = 'isocpeur'):
        import os
        try:
            base_dir = os.path.dirname(__file__)
            p_font_file = os.path.join(base_dir, json_font_name + '.json')
            if os.path.isfile(p_font_file):
                with open(p_font_file, "r") as json_file:
                    cls.letters_dict = json.load(json_file)
                    return True
            else:
                return False
        except Exception as e:
            print(f'Error when reading font file: {e}')

    @classmethod
    def process_string(cls, string):
        for letter in string:
            if letter in TextFactory.letters_dict:
                yield TextFactory.letters_dict[letter]

    @classmethod
    def grab_curves_to_json_font(
            cls, is_output_to_file: bool = False,
            json_font_name: str = 'isocpeur', append_space_character: bool = False,
            round_to: int = 4):

        split_by: int = 4
        selected_curves_data = {}

        for obj in bpy.context.selected_objects:
            if obj.type == 'CURVE':
                curve_data = obj.data

                curve_width = obj.dimensions.x
                curve_height = obj.dimensions.y

                curve_data_list = [curve_width, curve_height, []]
                for spline in curve_data.splines:
                    if len(spline.points) != 2:
                        continue
                    curve_data_list[2].append(
                        [[round(v, round_to) for v in spline.points[0].co[:2]],
                         [round(v, round_to) for v in spline.points[1].co[:2]]])
                selected_curves_data[obj.name] = curve_data_list

        if append_space_character:
            # print(selected_curves_data)
            # " ": [0.5, 0.1, []] Append SPACE
            selected_curves_data[' '] = [0.5, 0.1, []]

        if is_output_to_file:
            import os
            base_dir = os.path.dirname(__file__)
            p_font_file = os.path.join(base_dir, json_font_name + '.json')

            with open(p_font_file, "w") as json_file:
                json.dump(selected_curves_data, json_file)

            print("JSON file created successfully:", p_font_file)
        else:
            for v in [cls.format_entry(key, value, split_by) for key, value in selected_curves_data.items()]:
                print(v)


class MathVisualizer:
    def __init__(self, context: bpy.types.Context, pencil_name: str = '') -> None:

        self.display_mode = '3DSPACE' if context.space_data.type == 'VIEW_3D' else '2DSPACE'

        self.pencil = None
        if pencil_name:
            self.pencil = bpy.data.grease_pencils.get(pencil_name, None)
        else:
            self.pencil = bpy.context.annotation_data
        if not self.pencil:
            bpy.ops.gpencil.annotation_add()
            self.pencil = bpy.data.grease_pencils[-1]
            if pencil_name:
                self.pencil.name = pencil_name

    def clear(self, group: str, frame_idx: int):
        lines = self.pencil.layers.get(group, None)
        if lines is None:
            lines = self.pencil.layers.new(group)

        self.pencil.layers.active = lines

        p_vectors = None

        for it_frame in lines.frames:
            if it_frame.frame_number == frame_idx:
                p_vectors = it_frame

        if p_vectors is not None:
            p_vectors.clear()

    def add_cross(
            self,
            group: str, frame_idx: int,
            color: Color = None, size: float = 1.0,
            line_width: int = 3, position: tuple = (0.0, 0.0, 0.0),
            rotation: Matrix = Matrix(),
            clear: bool = True,
            show_in_front: bool = True):

        lines = self.pencil.layers.get(group, None)
        if lines is None:
            lines = self.pencil.layers.new(group)

        self.pencil.layers.active = lines

        p_vectors = None

        if color is not None:
            lines.color = color[:]
        lines.thickness = line_width

        lines.show_in_front = show_in_front

        for it_frame in lines.frames:
            if it_frame.frame_number == frame_idx:
                p_vectors = it_frame

        if p_vectors is None:
            p_vectors = lines.frames.new(frame_idx, active=True)

        if clear:
            p_vectors.clear()

        for co in AnnotationShapes.cross[2]:

            co_start, co_end = co

            vec_start = Vector(co_start) * size
            vec_start.resize_3d()
            vec_end = Vector(co_end) * size
            vec_end.resize_3d()

            gp_stroke = p_vectors.strokes.new()
            gp_stroke.start_cap_mode = 'ROUND'
            gp_stroke.end_cap_mode = 'ROUND'
            gp_stroke.use_cyclic = False

            gp_stroke.display_mode = self.display_mode

            gp_stroke.points.add(2)
            position = Vector(position)
            position.resize_3d()
            gp_stroke.points[0].co = rotation @ vec_start + position
            gp_stroke.points[-1].co = rotation @ vec_end + position

    def add_dot(
            self,
            group: str, frame_idx: int,
            color: Color = None, size: float = 1.0,
            line_width: int = 3, position: tuple = (0.0, 0.0, 0.0),
            rotation: Matrix = Matrix(),
            clear: bool = True,
            show_in_front: bool = True):

        lines = self.pencil.layers.get(group, None)
        if lines is None:
            lines = self.pencil.layers.new(group)

        self.pencil.layers.active = lines

        p_vectors = None

        if color is not None:
            lines.color = color[:]
        lines.thickness = line_width

        lines.show_in_front = show_in_front

        for it_frame in lines.frames:
            if it_frame.frame_number == frame_idx:
                p_vectors = it_frame

        if p_vectors is None:
            p_vectors = lines.frames.new(frame_idx, active=True)

        if clear:
            p_vectors.clear()

        for co in AnnotationShapes.get_dot('simple dot')[2]:

            co_start, co_end = co

            vec_start = Vector(co_start) * size
            vec_start.resize_3d()
            vec_end = Vector(co_end) * size
            vec_end.resize_3d()

            gp_stroke = p_vectors.strokes.new()
            gp_stroke.start_cap_mode = 'ROUND'
            gp_stroke.end_cap_mode = 'ROUND'
            gp_stroke.use_cyclic = False

            gp_stroke.display_mode = self.display_mode

            gp_stroke.points.add(2)
            position = Vector(position)
            position.resize_3d()
            gp_stroke.points[0].co = rotation @ vec_start + position
            gp_stroke.points[-1].co = rotation @ vec_end + position

    def add_text(
            self,
            group: str, frame_idx: int, text: str,
            color: Color = None, letters_size: float = 1.0,
            line_width: int = 3, position: tuple = (0.0, 0.0, 0.0),
            clear: bool = True,
            show_in_front: bool = True,
            space_between_letters: float = 0.3):

        lines = self.pencil.layers.get(group, None)
        if lines is None:
            lines = self.pencil.layers.new(group)

        self.pencil.layers.active = lines

        p_vectors = None

        if color is not None:
            lines.color = color[:]
        lines.thickness = line_width

        lines.show_in_front = show_in_front

        for it_frame in lines.frames:
            if it_frame.frame_number == frame_idx:
                p_vectors = it_frame

        if p_vectors is None:
            p_vectors = lines.frames.new(frame_idx, active=True)

        if clear:
            p_vectors.clear()

        if TextFactory.read_json_font(json_font_name='isocpeur') is False:
            return

        next_offset = 0.0
        for letter_width, letter_height, vectors in TextFactory.process_string(text):

            for co in vectors:
                if not len(co):
                    # Skip for SPACE reason
                    continue
                p_offset = Vector((next_offset, 0.0))
                co_start, co_end = co
                vec_start = (Vector(co_start) + p_offset) * letters_size
                vec_start.resize_3d()
                vec_end = (Vector(co_end) + p_offset) * letters_size
                vec_end.resize_3d()

                gp_stroke = p_vectors.strokes.new()
                gp_stroke.start_cap_mode = 'ROUND'
                gp_stroke.end_cap_mode = 'ROUND'
                gp_stroke.use_cyclic = False

                gp_stroke.display_mode = self.display_mode

                gp_stroke.points.add(2)

                gp_stroke.points[0].co = vec_start + Vector(position)
                gp_stroke.points[-1].co = vec_end + Vector(position)

            next_offset += letter_width + space_between_letters

    def add_vector(
            self,
            group: str, frame_idx: int, co_list: tuple,
            color: Color = None, clear: bool = True,
            is_constant_arrow_size: bool = True, arrow_size: float = 0.005,
            show_in_front: bool = True):

        lines = self.pencil.layers.get(group, None)
        if lines is None:
            lines = self.pencil.layers.new(group)

        self.pencil.layers.active = lines

        p_vectors = None

        if color is not None:
            lines.color = color[:]

        lines.show_in_front = show_in_front

        for it_frame in lines.frames:
            if it_frame.frame_number == frame_idx:
                p_vectors = it_frame

        if p_vectors is None:
            p_vectors = lines.frames.new(frame_idx, active=True)

        if clear:
            p_vectors.clear()

        for co in co_list:
            co_start, co_end = co
            vec_start = co_start.copy()
            vec_start.resize_3d()
            vec_end = co_end.copy()
            vec_end.resize_3d()

            gp_stroke = p_vectors.strokes.new()
            gp_stroke.start_cap_mode = 'ROUND'
            gp_stroke.end_cap_mode = 'ROUND'
            gp_stroke.use_cyclic = False

            gp_stroke.display_mode = self.display_mode

            gp_stroke.points.add(2)

            gp_stroke.points[0].co = vec_start
            gp_stroke.points[-1].co = vec_end

            axis_raw = vec_end - vec_start  # type: Vector
            distance = axis_raw.length
            if distance == 0:
                return

            if is_constant_arrow_size:
                vec_arrow = Vector((0, 1.0, 0)) * arrow_size
            else:
                distance /= 10
                vec_arrow = Vector((0, distance, 0)) * arrow_size * 400

            axis = axis_raw.normalized()  # type: Vector

            vec_right = vec_arrow.copy()
            vec_right.rotate(Matrix.Rotation(math.radians(-160), 4, "Z"))

            vec_left = vec_arrow.copy()
            vec_left.rotate(Matrix.Rotation(math.radians(160), 4, "Z"))

            mtxRotDir = axis.to_track_quat('Y', 'Z').to_matrix().to_4x4()

            vec_left = Matrix.Translation(vec_end) @ mtxRotDir @ vec_left
            vec_right = Matrix.Translation(vec_end) @ mtxRotDir @ vec_right

            gp_stroke_left = p_vectors.strokes.new()
            gp_stroke_left.start_cap_mode = 'ROUND'
            gp_stroke_left.end_cap_mode = 'ROUND'
            gp_stroke_left.use_cyclic = False

            gp_stroke_left.display_mode = self.display_mode

            gp_stroke_left.points.add(2)

            gp_stroke_left.points[0].co = vec_end
            gp_stroke_left.points[-1].co = vec_right

            gp_stroke_right = p_vectors.strokes.new()
            gp_stroke_right.start_cap_mode = 'ROUND'
            gp_stroke_right.end_cap_mode = 'ROUND'
            gp_stroke_right.use_cyclic = False

            gp_stroke_right.display_mode = self.display_mode

            gp_stroke_right.points.add(2)

            gp_stroke_right.points[0].co = vec_end
            gp_stroke_right.points[-1].co = vec_left
