# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


import bpy
import bmesh
from math import pi, radians

from ZenUV.utils import get_uv_islands as island_util
from mathutils import Vector
from ZenUV.utils.bounding_box import BoundingBox2d
from ZenUV.ops.transform_sys.transform_utils.tr_utils import ActiveUvImage
from ZenUV.ops.transform_sys.transform_utils.transform_loops import TransformLoops


class ZUV_OP_TestOperator(bpy.types.Operator):
    bl_idname = 'zenuv_test.test_operator'
    bl_label = 'Test Operator'
    bl_description = 'Executes particular Zen UV Tests'
    bl_options = {'REGISTER', 'UNDO'}

    # set_minimum: bpy.props.BoolProperty(
    #     name='Minimum distance',
    #     description='Sets the smallest distance sufficient for splitting but not visible to the eye',
    #     default=False)
    # distance: bpy.props.FloatProperty(
    #     name='Distance',
    #     default=0.005,
    #     min=0.0,
    #     precision=3,
    #     step=0.1)
    # per_vertex: bpy.props.BoolProperty(
    #     name='Per Vertex',
    #     description='Split each vertex separately',
    #     default=False)
    # split_ends: bpy.props.BoolProperty(
    #     name='Split Ends',
    #     description='Splits the ends. The gap remains the same along the entire length',
    #     default=False)

    orient_direction: bpy.props.EnumProperty(
        name="Direction",
        description="",
        items=[
            ("HORIZONTAL", "Horizontal", "Horizontal orientation"),
            ("VERTICAL", "Vertical", "Vertical orientation"),
            ("AUTO", "Auto", "Auto detect orientation"),
        ],
        default="AUTO"
    )
    rotate_direction: bpy.props.EnumProperty(
        name='Rotation',
        description="Direction of rotation",
        items=[
            ("CW", "Clockwise", ""),
            ("CCW", "Counter-clockwise", ""),
        ],
        default="CCW"
    )

    # def draw(self, context):
    #     layout = self.layout
    #     layout.prop(self, 'set_minimum')
    #     row = layout.row()
    #     row.enabled = not self.set_minimum
    #     row.prop(self, 'distance')
    #     layout.prop(self, 'per_vertex')
    #     row = layout.row()
    #     row.enabled = not self.per_vertex
    #     row.prop(self, 'split_ends')

    def execute(self, context):
        import bmesh
        from ZenUV.utils.generic import resort_by_type_mesh_in_edit_mode_and_sel

        objs = resort_by_type_mesh_in_edit_mode_and_sel(context)
        if not objs:
            self.report({'WARNING'}, "Zen UV: There are no selected objects.")
            return {"CANCELLED"}

        for obj in objs:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()

            image_aspect = ActiveUvImage(context).aspect
            # p_loops = LoopsFactory.loops_by_sel_mode(context, bm, uv_layer, groupped=True)

            for island in island_util.get_island(context, bm, uv_layer):
                # from ZenUV.ops.transform_sys.transform_utils.transform_uvs import TransformUVS
                # from ZenUV.utils.transform import zen_box_fit_2d
                # import math
                from mathutils import Matrix

                selected_loops = island_util.LoopsFactory.get_selected_loops_by_island(context, island, uv_layer)
                # p_points = {loop[uv_layer].uv.copy().freeze() for loop in selected_loops}
                p_points = [loop[uv_layer].uv for loop in selected_loops]
                p_selection_bbox = BoundingBox2d(points=p_points)

                p_island_bbox = BoundingBox2d(islands=[island, ], uv_layer=uv_layer)

                for area in context.screen.areas:
                    if area.type == 'IMAGE_EDITOR':
                        area.spaces.active.cursor_location = p_island_bbox.center

                cluster = [lp for f in island for lp in f.loops]

                print(f'{image_aspect = }')

                # S: Matrix = None
                # if image_aspect > 1.0:
                #     print(' aspect > 1')
                #     S = Matrix.Diagonal((1, 1 / image_aspect))
                # elif image_aspect < 1.0:
                #     print(' aspect < 1')
                #     S = Matrix.Diagonal((image_aspect, 1))
                # else:
                #     print(' aspect = 1')
                #     S = Matrix.Diagonal((1, 1))
                # print(f'Scale matrix = \n {S}')

                # angle = zen_box_fit_2d([S @ p for p in p_selection_bbox.points])

                # if abs(angle) > pi / 2:
                #     if angle < 0:
                #         angle += pi / 2
                #     else:
                #         angle -= pi / 2
                # if abs(angle) > pi / 4:
                #     if angle < 0:
                #         angle = pi / 2 + angle
                #     else:
                #         angle = - pi / 2 + angle

                # print(f'{degrees(angle) = }')

                angle = p_selection_bbox.get_orient_angle(image_aspect)

                angle = self.by_props_correction(p_selection_bbox, angle, self.orient_direction, self.rotate_direction)

                R: Matrix = None
                rotation_matrix = Matrix.Rotation(angle, 3, 'Z')

                if image_aspect > 1:
                    # Image is wider than tall, normalize by scaling the V axis
                    normalization_matrix = Matrix.Diagonal(Vector((1, 1 / image_aspect, 1)))
                    rescale_matrix = Matrix.Diagonal(Vector((1, image_aspect, 1)))
                else:
                    # Image is taller than wide, normalize by scaling the U axis
                    # normalization_matrix = Matrix.Diagonal(Vector((1 / image_aspect, 1, 1)))
                    normalization_matrix = Matrix.Diagonal(Vector((image_aspect, 1, 1)))
                    rescale_matrix = Matrix.Diagonal(Vector((1 / image_aspect, 1, 1)))

                R = (rescale_matrix @ rotation_matrix @ normalization_matrix).to_2x2()

                # uvs = ((R @ (loop[uv_layer].uv - p_selection_bbox.center)) + p_selection_bbox.center for loop in cluster)

                for loop in cluster:
                    loop[uv_layer].uv = (R @ (loop[uv_layer].uv - p_selection_bbox.center)) + p_selection_bbox.center

                # for loop, uv in zip(cluster, uvs):
                #     loop[uv_layer].uv = uv

                # self._orient_loops_by_predefined_angle(
                #     cluster, uv_layer, p_selection_bbox, image_aspect, self.orient_direction, self.rotate_direction, angle=angle)

                # else:

                #     self._orient_loops(cluster, uv_layer, p_selection_bbox, image_aspect, self.orient_direction, self.rotate_direction)

            bmesh.update_edit_mesh(obj.data)

        return {'FINISHED'}

    def _orient_loops(
        cls,
        cluster: list,
        uv_layer: bmesh.types.BMLayerItem,
        bbox: BoundingBox2d,
        image_aspect: float,
        orient_direction: str,
        rotate_direction: str
    ) -> None:

        angle = bbox.get_orient_angle(image_aspect)

        angle = cls.by_props_correction(bbox, angle, orient_direction, rotate_direction)

        TransformLoops.rotate_loops(
                    cluster,
                    uv_layer,
                    angle,
                    bbox.center,
                    image_aspect=image_aspect,
                    angle_in_radians=True
                )

    def _orient_loops_by_predefined_angle(
        cls,
        cluster: list,
        uv_layer: bmesh.types.BMLayerItem,
        bbox: BoundingBox2d,
        image_aspect: float,
        orient_direction: str,
        rotate_direction: str,
        angle: float = 0.0
    ) -> None:

        if angle == 0.0:
            return

        angle = cls.by_props_correction(bbox, angle, orient_direction, rotate_direction)

        TransformLoops.rotate_loops(
                    cluster,
                    uv_layer,
                    angle,
                    bbox.center,
                    image_aspect=image_aspect,
                    angle_in_radians=True
                )

    def by_props_correction(
        cls,
        bbox: BoundingBox2d,
        angle: radians,
        orient_direction: str = 'AUTO',
        rotate_direction: str = 'CW'
    ) -> None:
        """
        :param mode: enum in {'BBOX', 'BY_SELECTION}
        :param image_aspect: float
        :param orient_direction: enum in {'HORIZONTAL', 'VERTICAL'}
        :param rotate_direction: enum in {'CW', 'CWW'}
        """

        if not orient_direction == 'AUTO':
            if orient_direction == 'VERTICAL':
                if bbox.is_vertical is False:
                    angle = cls.fix_near_angle(angle)
            elif orient_direction == 'HORIZONTAL':
                if bbox.is_vertical is True:
                    angle = cls.fix_near_angle(angle)

            if not abs(angle) < 0.000001:
                if rotate_direction == 'CCW':
                    if angle <= 0:
                        angle += pi
                else:
                    if angle >= 0:
                        angle -= pi

        return angle

    def fix_near_angle(cls, angle: radians) -> radians:
        if angle < 0:
            return angle + pi / 2
        else:
            return angle - pi / 2

    def rotate_uv_coordinates_with_aspect(cls, uv_coords, angle, image_aspect):
        # import math
        from mathutils import Matrix, Vector
        # Convert angle to radians
        # angle_rad = math.radians(angle)

        # Rotation matrix
        rotation_matrix = Matrix.Rotation(angle, 2, 'Z').to_3x3()
        print(rotation_matrix)

        # Scale to normalize uneven aspect
        if image_aspect > 1:
            uv_scale = (1, 1 / image_aspect)  # Image is wider
        else:
            uv_scale = (image_aspect, 1)  # Image is taller

        scale_matrix = Matrix.Diagonal(Vector((1 / uv_scale[0], 1 / uv_scale[1], 1)))

        # Create a list to store transformed UV coordinates
        transformed_uvs = []

        # Find the centroid to rotate around
        centroid = Vector((sum(u[0] for u in uv_coords) / len(uv_coords),
                           sum(u[1] for u in uv_coords) / len(uv_coords), 0))

        for uv in uv_coords:
            uv_vector = Vector((uv[0], uv[1], 0))

            # Translate to origin
            centered_uv = uv_vector - centroid

            # Normalize aspect ratio, rotate, then rescale to the original aspect
            normalized_uv = scale_matrix @ centered_uv
            rotated_uv = rotation_matrix @ normalized_uv
            final_uv = (Matrix.Diagonal(Vector((uv_scale[0], uv_scale[1], 1))) @ rotated_uv) + centroid

            # Store the transformed UV coordinates
            transformed_uvs.append((final_uv.x, final_uv.y))
            yield (final_uv.x, final_uv.y)

        # return transformed_uvs


class ZUV_OP_SpeedTestOperator(bpy.types.Operator):
    bl_idname = 'zenuv_test.speed_test_operator'
    bl_label = 'Speed Test Operator'
    bl_description = 'Compares the speed of two functions.'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        import time

        def get_uv_bound_edges_indexes_original(faces, uv_layer):
            """ Return indexes of border edges of given island (faces) from current UV Layer """
            if not faces:
                return []

            edges = {edge for face in faces for edge in face.edges if edge.link_loops}
            return [edge.index for edge in edges
                    if edge.link_loops[0][uv_layer].uv
                    != edge.link_loops[0].link_loop_radial_next.link_loop_next[uv_layer].uv
                    or edge.link_loops[-1][uv_layer].uv
                    != edge.link_loops[-1].link_loop_radial_next.link_loop_next[uv_layer].uv]

        # Optimized function using bmesh
        def get_uv_bound_edges_indexes_optimized(faces, uv_layer):
            """ Return indexes of border edges of given island (faces) from current UV Layer """

            if not faces:
                return []

            edges = {edge for face in faces for edge in face.edges if edge.link_loops}
            uv_diff_edges = []

            for edge in edges:
                loop1, loop2 = edge.link_loops[0], edge.link_loops[-1]
                uv1_1, uv1_2 = loop1[uv_layer].uv, loop1.link_loop_radial_next.link_loop_next[uv_layer].uv
                uv2_1, uv2_2 = loop2[uv_layer].uv, loop2.link_loop_radial_next.link_loop_next[uv_layer].uv
                if uv1_1 != uv1_2 or uv2_1 != uv2_2:
                    uv_diff_edges.append(edge.index)

            return uv_diff_edges

        # Setup test data using bmesh
        def get_test_data(obj):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.active
            return bm, uv_layer

        obj = bpy.context.active_object
        bm, uv_layer = get_test_data(obj)
        # p_faces = bm.faces[200: 9000]
        p_faces = [f for f in bm.faces if f.select]
        print(f'{len(p_faces) = }')

        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_mode(type="EDGE")
        # Timing the original function
        start_time = time.time()
        original_result = get_uv_bound_edges_indexes_original(p_faces, uv_layer)
        original_time = time.time() - start_time

        # Timing the optimized function
        start_time = time.time()
        optimized_result = get_uv_bound_edges_indexes_optimized(p_faces, uv_layer)
        optimized_time = time.time() - start_time

        # Results
        print(f"Original function time: {original_time:.6f} seconds")
        print(f"Optimized function time: {optimized_time:.6f} seconds")

        # Verifying both functions return the same result
        assert original_result == optimized_result, "Results differ between original and optimized functions!"
        print("Both functions return the same result.")
        print(f'{len(optimized_result) = }')
        print(f'{len(original_result) = }')

        for i in optimized_result:
            bm.edges[i].select = True
        start_time = time.time()
        bmesh.update_edit_mesh(obj.data)
        update_time = time.time() - start_time
        print(f"Bmesh --> Mesh update time: {update_time:.6f} seconds")

        return {'FINISHED'}


def register_test_operator():
    bpy.utils.register_class(ZUV_OP_TestOperator)


def unregister_test_operator():
    bpy.utils.unregister_class(ZUV_OP_TestOperator)
