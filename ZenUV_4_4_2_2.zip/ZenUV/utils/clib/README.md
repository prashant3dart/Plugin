# Zen UV Core Library
It was introduced since Zen UV version 2.1.0 and is implemented as a shared library which is used as a wrapper for complex UV calculations.

![preview](../../../../Images/2021-06-22-15-54-43.png)

# Installation
## 1. From addon preferencies
![from_addon](../../../../Images/2021-06-22-15-48-58.png)

## 2. From Zen UV side panel
![from_side_panel](../../../../Images/2021-06-22-15-51-34.png)

