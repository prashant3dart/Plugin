# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2023, Valeriy Yatsenko

""" Zen UV draws functions for panels """
from ZenUV.prop.zuv_preferences import get_prefs
from ZenUV.ui.labels import ZuvLabels
from ZenUV.ico import icon_get


def draw_progress_bar(self, context):
    ''' @Draw Progress Bar '''
    if context.scene.zenuv_progress >= 0:
        self.layout.separator()
        text = context.scene.zenuv_progress_text
        self.layout.prop(
            context.scene,
            "zenuv_progress",
            text=text,
            slider=True
            )


def draw_unwrap(self, context):
    ''' @Draw Unwrap '''
    layout = self.layout

    # Zen Unwrap Section
    col = layout.column(align=True)
    row = col.row(align=True)
    row.operator(
        "uv.zenuv_unwrap",
        icon_value=icon_get(ZuvLabels.ZEN_UNWRAP_ICO)).action = "DEFAULT"
    row.popover(panel="ZENUNWRAP_PT_Properties", text="", icon="PREFERENCES")
    col.operator("uv.zenuv_unwrap_constraint")
    # layout.operator(ZUV_OT_ProjectByScreenCage.bl_idname)

    # Seams Section
    col = layout.column(align=True)
    row = col.row(align=True)
    row.operator("uv.zenuv_auto_mark")
    row.popover(panel="MARK_PT_Properties", text="", icon="PREFERENCES")
    row = col.row(align=True)
    row.operator(
        "uv.zenuv_mark_seams",
        icon_value=icon_get(ZuvLabels.OT_MARK_ICO),
        text='Mark').action = 'MARK'
    row.operator(
        "uv.zenuv_mark_seams",
        icon_value=icon_get(ZuvLabels.OT_UNMARK_ICO),
        text='Unmark').action = 'UNMARK'
    col.operator("uv.zenuv_unmark_all")

    # Seam By Section

    # col = col.column(align=True)
    row = col.row(align=True)
    row.prop(context.scene.zen_uv, "sl_convert", text="")
    row.operator("uv.zenuv_unified_mark", icon='KEYFRAME_HLT', text="")
    # col.operator("uv.zenuv_seams_by_uv_islands")
    # col.operator("uv.zenuv_seams_by_sharp")
    # col.operator("uv.zenuv_sharp_by_seams")
    # col.operator("uv.zenuv_seams_by_open_edges")
    layout.operator("mesh.zenuv_mirror_seams")

    # col = layout.column(align=True)
    layout.operator("view3d.zenuv_set_smooth_by_sharp")

    # draw_finished_section(self, context)

    # Quadrify Section

    # col = layout.column(align=True)
    # row = col.row(align=True)
    # row.operator("uv.zenuv_quadrify", icon_value=icon_get(TrLabels.ZEN_QUADRIFY_ICO))


def uv_draw_unwrap(self, context):
    ''' @Draw Unwrap UV '''
    # Zen Unwrap Section
    layout = self.layout
    row = layout.row(align=True)
    row.operator(
        "uv.zenuv_unwrap",
        icon_value=icon_get(ZuvLabels.ZEN_UNWRAP_ICO)).action = "DEFAULT"
    row.popover(panel="ZENUNWRAP_PT_Properties", text="", icon="PREFERENCES")
    layout.operator("uv.zenuv_unwrap_constraint")
    layout.operator('uv.zenuv_unwrap_inplace')
    # layout.operator(ZUV_OT_ProjectByScreenCage.bl_idname)


def draw_stack(self, context):
    ''' @Draw Stack '''
    addon_prefs = get_prefs()
    layout = self.layout
    # layout.split()
    main_ops_col = layout.column(align=False)
    if addon_prefs.st_stack_mode in {'ALL', 'SELECTED'}:

        draw_full_stack(addon_prefs, main_ops_col)

        row = main_ops_col.row(align=True)
        row.prop(get_prefs(), "st_stack_mode", text="")

        # if context.area.type == 'VIEW_3D':
        #     layout.split()
        #     deferred_displaying = ('PRIMARY', 'REPLICAS', 'SINGLES')
        #     row = layout.row(align=True)
        #     eye_row = row.row(align=True)
        #     if context.scene.zen_display.stack_display_mode not in deferred_displaying:
        #         eye_row.prop(context.scene.zen_display, "stack_display_solver", text="", toggle=True, icon='HIDE_OFF')
        #     row.prop(context.scene.zen_display, "stack_display_mode", text="")
        #     if context.scene.zen_display.stack_display_mode == 'STACKED':
        #         row.popover(panel="STACK_PT_DrawProperties", text="", icon="PREFERENCES")
        #         row.operator("uv.zenuv_select_stacked", text="", icon="RESTRICT_SELECT_OFF")
        #     if context.scene.zen_display.stack_display_mode in deferred_displaying:
        #         solver = context.scene.zen_display.stack_display_mode
        #         if solver == 'PRIMARY':
        #             desc = ZuvLabels.OT_SELECT_STACK_PRIMARY_DESC
        #         elif solver == 'REPLICAS':
        #             desc = ZuvLabels.OT_SELECT_STACK_REPLICAS_DESC
        #         elif solver == 'SINGLES':
        #             desc = ZuvLabels.OT_SELECT_STACK_SINGLES_DESC
        #         row.operator("uv.zenuv_select_stack", text="", icon="RESTRICT_SELECT_OFF").desc = desc
    else:

        draw_simple_stack(main_ops_col)
        row = main_ops_col.row(align=True)
        row.prop(get_prefs(), "st_stack_mode", text="")


def draw_full_stack(addon_prefs, col):
    ''' @Draw Stack Full '''
    from ZenUV.stacks.stacks import ZUV_OT_Stack_Similar, ZUV_OT_Unstack
    row = col.row(align=True)
    st = row.operator(ZUV_OT_Stack_Similar.bl_idname, text="Stack", icon_value=icon_get(ZuvLabels.ZEN_STACK_ICO))
    ust = row.operator(ZUV_OT_Unstack.bl_idname, text="Unstack")
    if addon_prefs.st_stack_mode == 'ALL':
        st.selected = False
        ust.UnstackMode = 'GLOBAL'
    elif addon_prefs.st_stack_mode == 'SELECTED':
        st.selected = True
        ust.UnstackMode = 'SELECTED'
    row.popover(panel="STACK_PT_Properties", text="", icon="PREFERENCES")


def draw_copy_paste(self, context):
    ''' @Draw Copy Paste '''
    layout = self.layout
    row = layout.row(align=True)
    row.operator("uv.zenuv_copy_param", icon="COPYDOWN")
    row.operator("uv.zenuv_paste_param", icon="PASTEDOWN")


def draw_simple_stack(main_ops_col):
    ''' @Draw Simple Stack '''
    row = main_ops_col.row(align=True)
    row.operator("uv.zenuv_simple_stack", text="Stack")
    row.operator("uv.zenuv_simple_unstack", text="Unstack")
