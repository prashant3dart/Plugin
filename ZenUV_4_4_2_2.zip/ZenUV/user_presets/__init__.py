# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2024, Alex Zhornyak

import bpy
import os
import shutil
from ZenUV.utils.blender_zen_utils import ZuvPresets


class ZUV_OT_PresetsLoadDefault(bpy.types.Operator):
    bl_idname = 'wm.zenuv_presets_load_default'
    bl_label = 'Load Default Presets'
    bl_description = 'Copy default presets that are shipped with the addon'
    bl_options = {'REGISTER'}

    preset_folder: bpy.props.StringProperty(
        name='Preset Folder Name',
        default=''
    )

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        wm = context.window_manager
        return wm.invoke_confirm(self, event)

    def execute(self, context: bpy.types.Context):
        try:
            if not self.preset_folder:
                raise RuntimeError('Preset folder name is not specified!')

            s_dir = os.path.dirname(__file__)
            s_source_path = os.path.join(s_dir, self.preset_folder)
            if not os.path.exists(s_source_path):
                raise RuntimeError(f'Preset folder - {self.preset_folder} does not exist!')

            s_target_path = os.path.join("presets", ZuvPresets.get_preset_path(self.preset_folder))
            s_target_path = bpy.utils.user_resource('SCRIPTS', path=s_target_path, create=True)

            shutil.copytree(s_source_path, s_target_path, dirs_exist_ok=True)

            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, str(e))

        return {'CANCELLED'}


classes = (
    ZUV_OT_PresetsLoadDefault,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
