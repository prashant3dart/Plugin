import bpy
prefs = bpy.context.preferences.addons["ZenUV"].preferences.favourite_props_UV

prefs.favourites.clear()

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Item'
item_sub_1.category = ''
item_sub_1.display_text = False
item_sub_1.command = ''
item_sub_1.mode = 'LABEL'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Item'
item_sub_1.category = ''
item_sub_1.display_text = True
item_sub_1.command = ''
item_sub_1.mode = 'LABEL'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'EVENT_I'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Item'
item_sub_1.category = ''
item_sub_1.display_text = True
item_sub_1.command = ''
item_sub_1.mode = 'LABEL'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'HEART'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Item'
item_sub_1.category = ''
item_sub_1.display_text = True
item_sub_1.command = ''
item_sub_1.mode = 'LABEL'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'EVENT_Z'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Item'
item_sub_1.category = ''
item_sub_1.display_text = True
item_sub_1.command = ''
item_sub_1.mode = 'LABEL'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'EVENT_E'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Item'
item_sub_1.category = ''
item_sub_1.display_text = True
item_sub_1.command = ''
item_sub_1.mode = 'LABEL'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'EVENT_N'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Item'
item_sub_1.category = ''
item_sub_1.display_text = True
item_sub_1.command = ''
item_sub_1.mode = 'LABEL'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'EVENT_U'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Item'
item_sub_1.category = ''
item_sub_1.display_text = True
item_sub_1.command = ''
item_sub_1.mode = 'LABEL'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'EVENT_V'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Zen Unwrap'
item_sub_1.category = 'Unwrap'
item_sub_1.display_text = True
item_sub_1.command = "uv.zenuv_unwrap(MarkUnwrapped=True,ProcessingMode='WHOLE_MESH',action='DEFAULT',correct_aspect=True,fill_holes=True,markSeamEdges=True,markSharpEdges=False,packAfUnwrap=True,post_td_mode='AVERAGED')"
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = True
item_sub_1.icon = 'zen-uv_32'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Unwrap Inplace'
item_sub_1.category = 'Unwrap'
item_sub_1.display_text = True
item_sub_1.command = "uv.zenuv_unwrap_inplace(correct_aspect=True,fill_holes=True,ignore_pins=False,influence_mode='ISLAND',orient='W_ORIENT',restore_location=True,restore_orientation=True,restore_size=True,size='KEEP',unwrap_allowed=True,urp_method='ANGLE_BASED',use_subsurf_data=False)"
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Relax'
item_sub_1.category = 'Transform'
item_sub_1.display_text = True
item_sub_1.command = "uv.zenuv_relax(correct_aspect=True,method='ZENRELAX',relax=True,select=False,show_log=True)"
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'OPEN'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = True
item_sub_1.icon = 'relax-1_32'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Quadrify'
item_sub_1.category = 'Transform'
item_sub_1.display_text = True
item_sub_1.command = "uv.zenuv_quadrify(auto_pin='SKIP',average_shape=True,correct_aspect=False,influence='ISLAND',mark_borders=True,mark_seams=True,mark_sharp=False,orient='ALIGN_TO_AXIS',post_td_mode='SKIP',shape='PER_FACE',skip_non_quads=False,tag_finished=False,use_pack_islands=False,use_selected_edges=False)"
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = True
item_sub_1.icon = 'quadrify_32'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'World Orient'
item_sub_1.category = 'Transform'
item_sub_1.display_text = True
item_sub_1.command = "uv.zenuv_world_orient(flip_by_axis=False,further_orient=True,method='HARD',rev_neg_x=False,rev_neg_y=False,rev_neg_z=False,rev_x=False,rev_y=False,rev_z=False)"
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Reshape Island'
item_sub_1.category = 'Transform'
item_sub_1.display_text = True
item_sub_1.command = 'uv.zenuv_reshape_island'
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Split'
item_sub_1.category = 'Transform'
item_sub_1.display_text = True
item_sub_1.command = 'uv.zenuv_split(distance=0.004999999888241291,per_vertex=False,set_minimum=False,split_ends=False)'
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Merge'
item_sub_1.category = 'Transform'
item_sub_1.display_text = True
item_sub_1.command = 'uv.zenuv_merge_uv_verts(threshold=0.009999999776482582,unselected=False,use_pinned=False,use_seams=False)'
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Stack'
item_sub_1.category = 'Stack'
item_sub_1.display_text = True
item_sub_1.command = 'uv.zenuv_stack_similar(selected=True,silent=True)'
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'OPEN'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = True
item_sub_1.icon = 'stack_32'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Unstack'
item_sub_1.category = 'Stack'
item_sub_1.display_text = True
item_sub_1.command = "uv.zenuv_unstack(use_iterative_unstack=False,UnstackMode='STACKED',breakStack=False,increment=1.0)"
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Stack Mode'
item_sub_1.category = 'Stack'
item_sub_1.display_text = False
item_sub_1.command = 'preferences.addons["ZenUV"].preferences.st_stack_mode'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Select by TD'
item_sub_1.category = 'Texel Density'
item_sub_1.display_text = True
item_sub_1.command = "uv.zenuv_select_by_texel_density(clear_selection=True,desc='Select islands by texel density',influence='ISLAND',range_hi=1.0,range_low=0.0,sel_overrated=False,sel_underrated=False,selection_mode='TRESHOLD',texel_density=1024.0,treshold=0.009999999776482582)"
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'OPEN'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'RESTRICT_SELECT_OFF'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Current TD'
item_sub_1.category = 'Texel Density'
item_sub_1.display_text = False
item_sub_1.command = 'scene.zen_uv.td_props.prp_current_td'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'TD Unit'
item_sub_1.category = 'Texel Density'
item_sub_1.display_text = False
item_sub_1.command = 'scene.zen_uv.td_props.td_unit'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Texture Size'
item_sub_1.category = 'Texel Density'
item_sub_1.display_text = True
item_sub_1.command = 'scene.zen_uv.td_props.td_im_size_presets'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'TEXTURE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Get TD'
item_sub_1.category = 'Texel Density'
item_sub_1.display_text = True
item_sub_1.command = 'uv.zenuv_get_texel_density()'
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Set TD'
item_sub_1.category = 'Texel Density'
item_sub_1.display_text = True
item_sub_1.command = "uv.zenuv_set_texel_density(global_mode=True,image_size_x=1024,image_size_y=1024,island_pivot='cen',set_mode='OVERALL',td_value=10.239999771118164,units='m')"
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Texel Density Mode'
item_sub_1.category = 'Texel Density'
item_sub_1.display_text = False
item_sub_1.command = 'scene.zen_uv.td_props.td_set_mode'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'COL'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Checker Texture'
item_sub_1.category = 'UV Checker'
item_sub_1.display_text = True
item_sub_1.command = 'view3d.zenuv_checker_toggle()'
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'OPEN'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = True
item_sub_1.icon = 'checker_32'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'UV Checker'
item_sub_1.category = 'UV Checker'
item_sub_1.display_text = False
item_sub_1.command = 'preferences.addons["ZenUV"].preferences.SizesX'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'TEXTURE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'ZenCheckerImages'
item_sub_1.category = 'UV Checker'
item_sub_1.display_text = False
item_sub_1.command = 'preferences.addons["ZenUV"].preferences.ZenCheckerImages'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Display'
item_sub_1.category = 'UV Checker'
item_sub_1.display_text = True
item_sub_1.command = 'ZUV_PT_UVL_CheckDisplayPanel'
item_sub_1.mode = 'PANEL'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = ''

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Pack Islands'
item_sub_1.category = 'Pack'
item_sub_1.display_text = True
item_sub_1.command = 'uv.zenuv_pack(disable_overlay=False,display_uv=True,fast_mode=False)'
item_sub_1.mode = 'OPERATOR'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'OPEN'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = True
item_sub_1.icon = 'pack'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Texture Size'
item_sub_1.category = 'Pack'
item_sub_1.display_text = True
item_sub_1.command = 'scene.zen_uv.td_props.td_im_size_presets'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = True
item_sub_1.is_icon_value = False
item_sub_1.icon = 'TEXTURE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Margin px'
item_sub_1.category = 'Pack'
item_sub_1.display_text = True
item_sub_1.command = 'preferences.addons["ZenUV"].preferences.margin_px'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Average Scale'
item_sub_1.category = 'Pack'
item_sub_1.display_text = True
item_sub_1.command = 'preferences.addons["ZenUV"].preferences.averageBeforePack'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'ROW'
item_sub_1.layout_group = 'CLOSE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

item_sub_1 = prefs.favourites.add()
item_sub_1.name = 'Rotate Islands'
item_sub_1.category = 'Pack'
item_sub_1.display_text = True
item_sub_1.command = 'preferences.addons["ZenUV"].preferences.rotateOnPack'
item_sub_1.mode = 'PROPERTY'
item_sub_1.layout = 'AUTO'
item_sub_1.layout_group = 'NONE'
item_sub_1.icon_only = False
item_sub_1.is_icon_value = False
item_sub_1.icon = 'NONE'

prefs.favourite_index = 29
prefs.expanded = "{'UV': False, 'Pack': True, 'UV Checker': True, 'Texel Density': True, 'Stack': True, 'Transform': True, 'Unwrap': True}"
prefs.show_header = True
prefs.header_expanded = True
