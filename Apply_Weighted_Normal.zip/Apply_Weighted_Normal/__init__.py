bl_info = {
    "name": "Apply Weighted Normal",
    "blender": (4, 2, 0),
    "category": "Object Normal",
    "author": "Tech Boy JaTiX",
    "version": (1, 3, 0), 
    "description": "Apply Smooth by angle and Weighted Normal Modifiers in Object and Edit Mode",
}

import bpy
import math

class OBJECT_OT_apply_modifiers(bpy.types.Operator):
    bl_idname = "object.apply_modifiers"
    bl_label = "Apply Weighted Normal"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply Smooth by Angle and Weighted Normal modifiers"

    def execute(self, context):
        obj = context.active_object

        if obj is None:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'WARNING'}, "Active object is not a mesh")
            return {'CANCELLED'}
        
        # Store current mode to return to it later
        current_mode = context.mode
        was_in_edit_mode = 'EDIT' in current_mode
        
        # If in edit mode, switch to object mode to apply modifiers
        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Apply smooth shading
        bpy.ops.object.shade_smooth()
        
        # Clear custom normals
        bpy.ops.mesh.customdata_custom_splitnormals_clear()
        
        # Remove existing modifiers
        base_modifiers = ["WeightedNormal", "Smooth by Angle", "GeometryNodes"]
        for modifier in obj.modifiers:
            if any(modifier.name.startswith(base) for base in base_modifiers):
                bpy.ops.object.modifier_remove(modifier=modifier.name)
        
        # Auto smooth with adjustable angle from scene properties
        auto_smooth_angle = context.scene.auto_smooth_angle
        bpy.ops.object.shade_auto_smooth(angle=auto_smooth_angle)
        
        # Add and configure Weighted Normal modifier
        bpy.ops.object.modifier_add(type='WEIGHTED_NORMAL')
        weighted_normal_modifier = obj.modifiers["WeightedNormal"]
        weighted_normal_modifier.mode = 'FACE_AREA_WITH_ANGLE'
        weighted_normal_modifier.keep_sharp = True 
        
        # Apply modifiers
        bpy.ops.object.modifier_apply(modifier="WeightedNormal", report=True)
        
        # Apply ALL Smooth by Angle modifiers (including numbered ones)
        smooth_modifiers = [mod for mod in obj.modifiers if mod.name.startswith("Smooth by Angle")]
        for modifier in smooth_modifiers:
            bpy.ops.object.modifier_apply(modifier=modifier.name, report=True)
        
        # Apply ALL Geometry Nodes modifiers with "Smooth by Angle" in their names
        geometry_nodes_modifiers = [mod for mod in obj.modifiers if mod.type == 'NODES' and "Smooth by Angle" in mod.name]
        for modifier in geometry_nodes_modifiers:
            bpy.ops.object.modifier_apply(modifier=modifier.name, report=True)
        
        # Return to original mode if we were in edit mode
        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='EDIT')
            
        self.report({'INFO'}, "Modifiers applied successfully")
        return {'FINISHED'}

class OBJECT_OT_set_auto_smooth(bpy.types.Operator):
    bl_idname = "object.set_auto_smooth"
    bl_label = "Set Auto Smooth Angle"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set auto smooth angle for selected objects"

    def execute(self, context):
        obj = context.active_object

        if obj is None:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'WARNING'}, "Active object is not a mesh")
            return {'CANCELLED'}
        
        # Store current mode to return to it later
        current_mode = context.mode
        was_in_edit_mode = 'EDIT' in current_mode
        
        # If in edit mode, switch to object mode
        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Apply smooth shading if not already smooth
        bpy.ops.object.shade_smooth()
        
        # Set auto smooth with adjustable angle
        auto_smooth_angle = context.scene.auto_smooth_angle
        bpy.ops.object.shade_auto_smooth(angle=auto_smooth_angle)
        
        # Return to original mode if we were in edit mode
        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='EDIT')
        
        # Convert radians to degrees for the report message
        auto_smooth_angle_degrees = math.degrees(auto_smooth_angle)
        self.report({'INFO'}, f"Auto smooth angle set to {auto_smooth_angle_degrees:.1f}°")
        return {'FINISHED'}

class VIEW3D_PT_apply_modifiers_panel(bpy.types.Panel):
    bl_label = "Normal Tools"
    bl_idname = "VIEW3D_PT_apply_modifiers"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'
    
    def draw(self, context):
        layout = self.layout
        
        # Auto Smooth Angle Settings
        box = layout.box()
        box.label(text="Auto Smooth Settings")
        row = box.row()
        row.prop(context.scene, "auto_smooth_angle", text="Angle")
        row = box.row()
        row.operator("object.set_auto_smooth", text="Set Auto Smooth")
        
        # Separator
        layout.separator()
        
        # Main Apply Modifiers Button
        layout.operator("object.apply_modifiers", text="Apply Weighted Normal")
        
        # Show current shortcut if assigned
        addon_prefs = context.preferences.addons[__name__].preferences
        if addon_prefs.shortcut_key:
            layout.label(text=f"Shortcut: {addon_prefs.shortcut_key}")

# Addon Preferences
class APPLYWEIGHTEDNORMAL_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    shortcut_key: bpy.props.StringProperty(
        name="Shortcut Key",
        description="Set a shortcut key for Apply Weighted Normal (e.g., 'A', 'F9', etc.)",
        default="W",
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Set a shortcut key for Apply Weighted Normal:")
        layout.prop(self, "shortcut_key")
        
        if self.shortcut_key:
            layout.label(text=f"Current shortcut: Shift+Alt+{self.shortcut_key}", icon='INFO')
            layout.label(text="Go to Edit → Preferences → Keymap to modify this key")
        else:
            layout.label(text="No shortcut set", icon='ERROR')

# Keymap Handler
addon_keymaps = []

def register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        addon_prefs = bpy.context.preferences.addons[__name__].preferences
        if addon_prefs.shortcut_key:
            km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
            kmi = km.keymap_items.new(
                OBJECT_OT_apply_modifiers.bl_idname,
                type=addon_prefs.shortcut_key,
                value='PRESS',
                shift=True,
                alt=True
            )
            addon_keymaps.append((km, kmi))

def unregister_keymaps():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

# Scene properties for storing the angle
def update_auto_smooth_angle(self, context):
    # Optional: Auto-update selected objects when angle is changed
    pass

# Update handler for preferences
@bpy.app.handlers.persistent
def update_shortcut_handler(scene):
    # Re-register keymaps when preferences change
    unregister_keymaps()
    register_keymaps()

def register():
    bpy.utils.register_class(OBJECT_OT_apply_modifiers)
    bpy.utils.register_class(OBJECT_OT_set_auto_smooth)
    bpy.utils.register_class(VIEW3D_PT_apply_modifiers_panel)
    bpy.utils.register_class(APPLYWEIGHTEDNORMAL_AddonPreferences)
    
    # Register scene property for auto smooth angle
    bpy.types.Scene.auto_smooth_angle = bpy.props.FloatProperty(
        name="Auto Smooth Angle",
        description="Angle for auto smooth in radians",
        default=3.14159,  # 180 degrees in radians (pi)
        min=0.0,
        max=3.14159,  # 0 to 180 degrees
        subtype='ANGLE',
        unit='ROTATION',
        update=update_auto_smooth_angle
    )
    
    # Register keymaps
    register_keymaps()
    
    # Add handler to update shortcuts when preferences change
    if update_shortcut_handler not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(update_shortcut_handler)
    
def unregister():
    # Remove handler
    if update_shortcut_handler in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(update_shortcut_handler)
    
    # Unregister keymaps
    unregister_keymaps()
    
    bpy.utils.unregister_class(APPLYWEIGHTEDNORMAL_AddonPreferences)
    bpy.utils.unregister_class(OBJECT_OT_apply_modifiers)
    bpy.utils.unregister_class(OBJECT_OT_set_auto_smooth)
    bpy.utils.unregister_class(VIEW3D_PT_apply_modifiers_panel)
    
    # Unregister scene property
    del bpy.types.Scene.auto_smooth_angle

if __name__ == "__main__":
    register()