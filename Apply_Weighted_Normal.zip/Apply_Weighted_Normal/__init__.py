bl_info = {
    "name": "Apply Weighted Normal",
    "blender": (4, 2, 0),
    "category": "Object Normal",
    "author": "Tech Boy JaTiX",
    "version": (1, 1, 0),
    "description": "Apply Smooth by angle and Weight Normal Modifiers",
}

import bpy

class OBJECT_OT_apply_modifiers(bpy.types.Operator):
    bl_idname = "object.apply_modifiers"
    bl_label = "Apply Weighted Normal"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply Smooth by Angle and Weighted Normal modifiers"

    def execute(self, context):
        obj = context.active_object

        if obj is None:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'WARNING'}, "Active object is not a mesh")
            return {'CANCELLED'}

        # Clear custom split normals if they exist
        if obj.data.use_auto_smooth:
            bpy.ops.mesh.customdata_custom_splitnormals_clear()

        # Apply the modifiers if they exist
        smooth_mod_name = "Smooth by Angle"
        weighted_normal_mod_name = "Weighted Normal"

        # Apply the Smooth by Angle modifier
        if smooth_mod_name in obj.modifiers:
            try:
                bpy.ops.object.modifier_apply(modifier=smooth_mod_name)
            except Exception as e:
                self.report({'ERROR'}, f"Failed to apply {smooth_mod_name}: {str(e)}")
                return {'CANCELLED'}

        # Apply the Weighted Normal modifier
        if weighted_normal_mod_name in obj.modifiers:
            try:
                bpy.ops.object.modifier_apply(modifier=weighted_normal_mod_name)
            except Exception as e:
                self.report({'ERROR'}, f"Failed to apply {weighted_normal_mod_name}: {str(e)}")
                return {'CANCELLED'}

        # Check if the node group exists
        if "Smooth by Angle" in bpy.data.node_groups:
            try:
                # Add the node group modifier
                bpy.ops.object.modifier_add(type='NODES')
                node_mod = obj.modifiers[-1]  # Get the last added modifier
                node_mod.node_group = bpy.data.node_groups["Smooth by Angle"]
                node_mod["Input_1"] = 3.14159  # Set input value
            except Exception as e:
                self.report({'ERROR'}, f"Failed to add node group modifier: {str(e)}")
                return {'CANCELLED'}
        else:
            self.report({'WARNING'}, "Node group 'Smooth by Angle' not found. Skipping node group modifier application.")

        # Add and configure the Weighted Normal modifier
        weighted_normal_mod = obj.modifiers.new(name=weighted_normal_mod_name, type='WEIGHTED_NORMAL')
        weighted_normal_mod.mode = 'FACE_AREA_WITH_ANGLE'
        weighted_normal_mod.keep_sharp = True

        # Apply the modifiers
        try:
            if 'NODES' in obj.modifiers:
                bpy.ops.object.modifier_apply(modifier=node_mod.name)
            bpy.ops.object.modifier_apply(modifier=weighted_normal_mod.name)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply modifiers: {str(e)}")
            return {'CANCELLED'}

        self.report({'INFO'}, "Modifiers applied successfully")
        return {'FINISHED'}

class VIEW3D_PT_apply_modifiers_panel(bpy.types.Panel):
    bl_label = "Apply Modifiers"
    bl_idname = "VIEW3D_PT_apply_modifiers"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.apply_modifiers", text="Apply Modifiers")

def register():
    bpy.utils.register_class(OBJECT_OT_apply_modifiers)
    bpy.utils.register_class(VIEW3D_PT_apply_modifiers_panel)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_apply_modifiers)
    bpy.utils.unregister_class(VIEW3D_PT_apply_modifiers_panel)

if __name__ == "__main__":
    register()
