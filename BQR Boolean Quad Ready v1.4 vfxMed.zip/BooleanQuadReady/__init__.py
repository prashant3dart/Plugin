bl_info = {
    "name": "Boolean Quad Ready",
    "author": "Artemis3D",
    "version": (1, 4),
    "blender": (4, 3, 0),
    "location": "View3D > Sidebar > BQR Tab",
    "description": "Prepares mesh for boolean operations using clean quads",
    "category": "Object",
}

import bpy, bmesh, time, math
from bpy.props import IntProperty, FloatProperty, PointerProperty, BoolProperty

# === Utility ===
def modifier_exists(obj, mod_type): return any(mod.type == mod_type for mod in obj.modifiers)
def get_modifier(obj, mod_type): return next((mod for mod in obj.modifiers if mod.type == mod_type), None)
def has_modifier_stack(obj, types): return all(t in [mod.type for mod in obj.modifiers] for t in types)

# === Property Update Functions ===
def update_modifier_prop(self, context, mod_type, prop_name, value_attr, transform=lambda x: x):
    mod = get_modifier(context.active_object, mod_type)
    if mod: setattr(mod, prop_name, transform(getattr(self, value_attr)))

def update_remesh_depth(self, context): update_modifier_prop(self, context, 'REMESH', 'octree_depth', 'remesh_depth')
def update_remesh_scale(self, context): update_modifier_prop(self, context, 'REMESH', 'scale', 'remesh_scale')
def update_bevel_amount(self, context): update_modifier_prop(self, context, 'BEVEL', 'width', 'bevel_amount')
def update_bevel_segments(self, context): update_modifier_prop(self, context, 'BEVEL', 'segments', 'bevel_segments')
def update_bevel_angle(self, context): update_modifier_prop(self, context, 'BEVEL', 'angle_limit', 'bevel_angle', lambda x: x * (math.pi / 180))
def update_bevel_profile(self, context): update_modifier_prop(self, context, 'BEVEL', 'profile', 'bevel_profile')
def update_subsurf_level(self, context): update_modifier_prop(self, context, 'SUBSURF', 'levels', 'subsurf_level')
def update_smooth_repeat(self, context): update_modifier_prop(self, context, 'SMOOTH', 'iterations', 'smooth_repeat')
def update_decimate_iterations(self, context): update_modifier_prop(self, context, 'DECIMATE', 'iterations', 'decimate_iterations')

# === Operators ===
class __xCLR_M(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_clear_modifiers", "Clear BQR Modifiers", "Remove all modifiers added by RemeshIT"
    def execute(self, context):
        obj = context.active_object
        to_remove = ['REMESH', 'BEVEL', 'SUBSURF', 'SMOOTH']
        for mod in obj.modifiers[:]:
            if mod.type in to_remove: obj.modifiers.remove(mod)
        self.report({'INFO'}, "BQR Modifiers removed")
        return {'FINISHED'}

class BQRProperties(bpy.types.PropertyGroup):
    def update_beauty_bevel(self, context):
        mod = get_modifier(context.active_object, 'BEVEL')
        if mod: mod.miter_outer = 'MITER_ARC' if self.use_beauty_bevel else 'MITER_SHARP'
        
    def update_mirror_toggle(self, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            mirror = get_modifier(obj, 'MIRROR')
            if self.use_mirror:
                if not mirror:
                    # Create mirror collection if it doesn't exist
                    mirror_collection = bpy.data.collections.get("BQR Mirror")
                    if not mirror_collection:
                        mirror_collection = bpy.data.collections.new("BQR Mirror")
                        context.scene.collection.children.link(mirror_collection)
                        mirror_collection.color_tag = 'COLOR_04'  # Blue color
                    
                    # Create an empty at world center for mirror object
                    empty = bpy.data.objects.new(f"{obj.name}_mirror", None)
                    mirror_collection.objects.link(empty)
                    empty.empty_display_type = 'ARROWS'
                    empty.empty_display_size = 1.0
                    empty.location = (0, 0, 0)
                    empty.show_name = True  # Display name in viewport
                    
                    # Add mirror modifier
                    mirror = obj.modifiers.new(name="Mirror", type='MIRROR')
                    mirror.use_pin_to_last = True
                    mirror.mirror_object = empty
                    # Move to the end of the stack
                    bpy.ops.object.modifier_move_to_index(modifier=mirror.name, index=len(obj.modifiers)-1)
                    # Set property to show we created an empty
                    self.mirror_empty_created = True
                    # Update the mirror object property
                    self.mirror_object = empty
                else:
                    # If modifier exists but is hidden, show it
                    mirror.show_viewport = True
            else:
                # Instead of removing, hide the modifier
                if mirror:
                    mirror.show_viewport = False
    
    def update_mirror_setting(self, context):
        obj = context.active_object
        mirror = get_modifier(obj, 'MIRROR')
        if mirror:
            mirror.use_axis[0] = self.mirror_use_axis_x
            mirror.use_axis[1] = self.mirror_use_axis_y
            mirror.use_axis[2] = self.mirror_use_axis_z
            mirror.mirror_object = self.mirror_object
            mirror.use_clip = self.mirror_use_clip
            mirror.use_mirror_merge = self.mirror_use_merge
            # Move to the end of the stack
            bpy.ops.object.modifier_move_to_index(modifier=mirror.name, index=len(obj.modifiers)-1)

    # Define properties
    use_beauty_bevel: BoolProperty(
        name="Beauty Bevel", description="disable if geometry breaks",
        update=update_beauty_bevel, default=True)
    
    # Mirror properties
    use_mirror: BoolProperty(
        name="Mirror", description="Toggle mirror modifier",
        update=update_mirror_toggle, default=False)
    mirror_empty_created: BoolProperty(
        default=False, options={'HIDDEN', 'SKIP_SAVE'})
    mirror_use_axis_x: BoolProperty(
        name="X", description="Mirror along X axis",
        update=update_mirror_setting, default=True)
    mirror_use_axis_y: BoolProperty(
        name="Y", description="Mirror along Y axis",
        update=update_mirror_setting, default=False)
    mirror_use_axis_z: BoolProperty(
        name="Z", description="Mirror along Z axis",
        update=update_mirror_setting, default=False)
    mirror_object: PointerProperty(
        type=bpy.types.Object, name="Mirror Object",
        description="Object to use as mirror center",
        update=update_mirror_setting)
    mirror_use_clip: BoolProperty(
        name="Clip", description="Prevent vertices from going through the mirror",
        update=update_mirror_setting, default=True)
    mirror_use_merge: BoolProperty(
        name="Merge", description="Merge vertices on the mirror plane",
        update=update_mirror_setting, default=True)
    remesh_depth: IntProperty(
        name="Octree Depth", description="Controls the detail level of the Remesh modifier. Higher values produce finer geometry. Tip: Increase if booleans distort geometry.",
        default=4, min=1, max=9, update=update_remesh_depth)
    remesh_scale: FloatProperty(
        name="Scale", description="Controls the spacing of the remesh grid. Higher values result in denser mesh. Tip: Increase it if the mesh produces holes or lower it as the Octree Depth increases",
        default=0.9, min=0.01, max=1.0, update=update_remesh_scale)
    bevel_amount: FloatProperty(
        name="Amount", description="Thickness of the bevel. Tip: Keep it small for subtle edges or increase to round corners more.",
        default=0.02, min=0.001, max=1.0, update=update_bevel_amount)
    bevel_segments: IntProperty(
        name="Segments", description="Number of segments in the bevel. More segments mean smoother curves. Tip: Use 2-3 for most cases.",
        default=3, min=1, max=10, update=update_bevel_segments)
    bevel_angle: FloatProperty(
        name="Angle", description="Minimum angle in degrees to apply the bevel. Tip: Lower this to bevel sharper edges only.",
        default=30.0, min=0.0, max=180.0, update=update_bevel_angle)
    bevel_profile: FloatProperty(
        name="Shape", description="Controls the curve of the bevel. 0 is concave, 1 is convex. Tip: Keep around 0.5 for uniform rounding.",
        default=0.5, min=0.0, max=1.0, update=update_bevel_profile)
    subsurf_level: IntProperty(
        name="Subdivision Level", description="Number of subdivision levels for smoothing. Tip: Use 1-2 for general work, higher only if needed.",
        default=1, min=0, max=5, update=update_subsurf_level)
    smooth_repeat: IntProperty(
        name="Smooth Repeat", description="How many times to apply smoothing. Tip: Use to soften shading or fix small artifacts.",
        default=15, min=1, max=100, update=update_smooth_repeat)
    decimate_iterations: IntProperty(
        name="Last Decimate Value", description="Memorizza l'ultimo valore utilizzato per Decimate",
        default=2, min=1, max=10, options={'HIDDEN', 'SKIP_SAVE'})
    clean_edge_loops_last_angle: FloatProperty(
        name="Last Clean Angle", description="Memorizza l'ultimo angolo utilizzato per Clean Edge Loops",
        default=5.0, options={'HIDDEN', 'SKIP_SAVE'})
    use_triangulate_in_clean_loops: BoolProperty(
        name="Triangulate & Requad", description="Triangulate mesh and convert back to quads for improved topology",
        default=False)

# Edge loops optimization functions
def get_loop(bm, e):
    checkverts, checkedverts, loop_edges = e.verts[:], [], [e]
    checkedverts_set, loop_edges_set = set(), {e}
    
    while checkverts:
        v = checkverts.pop()
        if v in checkedverts_set: continue
        checkedverts.append(v)
        checkedverts_set.add(v)
        
        if len(v.link_edges) == 4:
            estart = next((e for e in v.link_edges if e in loop_edges_set), None)
            if estart:
                for e in v.link_edges:
                    if e in loop_edges_set: continue
                    isneighbour = any(f in estart.link_faces for f in e.link_faces)
                    if not isneighbour:
                        loop_edges.append(e)
                        loop_edges_set.add(e)
                        for v_new in e.verts:
                            if v_new not in checkedverts_set and v_new not in checkverts:
                                checkverts.append(v_new)
    return loop_edges

def check_angles(edges, angle_threshold):
    for e in edges:
        if len(e.link_faces) != 2: return False
        try:
            if e.calc_face_angle() > angle_threshold: return False
        except ValueError: return False
    return True

def has_complex_topology(edges):
    if len(edges) < 3: return True
    angles = []
    for e in edges:
        if len(e.link_faces) == 2:
            try: angles.append(e.calc_face_angle())
            except ValueError: continue
    if len(angles) < 3: return True
    if max(angles, default=0) > 0.5: return True
    if not angles: return True
    
    mean = sum(angles) / len(angles)
    prev = angles[0]
    for angle in angles[1:]:
        if abs(angle - prev) > 0.25: return True
        prev = angle
    
    variance = sum((x - mean) ** 2 for x in angles) / len(angles)
    std_dev = variance ** 0.5
    return std_dev > 0.15

class edgeloop:
    def __init__(self):
        self.edges = []
        self.neighbours = []

def get_neighbours(loops):
    for l in loops:
        l.neighbours = []
    for l in loops:
        e = l.edges[0]
        neighbours = 0
        for f in e.link_faces:
            if len(f.verts) == 4:
                for e1 in f.edges:
                    if e1 != e:
                        do = True
                        for v in e1.verts:
                            if v in e.verts: do = False
                        if do:
                            for l1 in loops:
                                if l1 != l and e1 in l1.edges:
                                    neighbours += 1
                                    if l1 not in l.neighbours:
                                        l.neighbours.append(l1)
                                        l1.neighbours.append(l)

class __xAPL_A(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_apply_all", "Apply Modifiers", "Apply all modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        backup_collection = bpy.data.collections.get("BQR Backup")
        if not backup_collection:
            backup_collection = bpy.data.collections.new("BQR Backup")
            context.scene.collection.children.link(backup_collection)
            backup_collection.color_tag = 'COLOR_06'

        backup_obj = obj.copy()
        backup_obj.data = obj.data.copy()
        backup_collection.objects.link(backup_obj)
        backup_obj.name = f"{obj.name}_BQR_Backup"
        backup_obj.hide_set(True)

        bpy.ops.object.convert(target='MESH')
        return {'FINISHED'}

class __xOPT_M(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_optimize", "Optimize", "Decimate using Unsubdivide"
    bl_options = {'REGISTER', 'UNDO'}
    
    iterations: IntProperty(
        name="Unsubdivide Iterations",
        description="Controls mesh simplification using the Unsubdivide algorithm",
        default=2, min=1, max=10)

    def execute(self, context):
        obj = context.active_object
        props = context.scene.bqr_props

        if modifier_exists(obj, 'DECIMATE'):
            self.report({'WARNING'}, "Optimize has already been applied")
            return {'CANCELLED'}

        dec = obj.modifiers.new(name="Decimate", type='DECIMATE')
        dec.decimate_type = 'UNSUBDIV'
        dec.iterations = self.iterations
        props.decimate_iterations = self.iterations
        
        self.report({'INFO'}, f"Optimize applied with {self.iterations} iterations")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        self.iterations = context.scene.bqr_props.decimate_iterations
        return context.window_manager.invoke_props_dialog(self)

class __xUV_W(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_uv_unwrap", "UV Unwrap", "Automatically unwrap mesh and pack islands"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh")
            return {'CANCELLED'}

        bpy.ops.object.convert(target='MESH')
        if not obj.data.uv_layers:
            obj.data.uv_layers.new(name="UVMap")
        else:
            obj.data.uv_layers.active_index = 0

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.smart_project()
        bpy.ops.object.mode_set(mode='OBJECT')

        self.report({'INFO'}, "Cube Projection UV completed")
        return {'FINISHED'}

class __xCLN_L(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_clean_loops", "Clean Edge Loops", "Remove redundant edge loops based on angle threshold"
    bl_options = {'REGISTER', 'UNDO'}
    
    angle: FloatProperty(
        name="Angle Threshold",
        description="Edge loops with angles below this threshold will be removed",
        default=5.0, min=0.01, max=180.0)
    
    preserve_boundary_loops: BoolProperty(
        name="Preserve Boundary Loops",
        description="Keep edge loops near sharp boundaries intact",
        default=True)
    
    min_loop_length: IntProperty(
        name="Min Loop Length",
        description="Minimum number of edges in a loop to consider for removal",
        default=3, min=1, max=20)

    triangulate: BoolProperty(
        name="Triangulate & Requad",
        description="Triangulate mesh and convert back to quads for improved topology",
        default=True)

    def execute(self, context):
        obj = context.active_object
        props = context.scene.bqr_props

        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh")
            return {'CANCELLED'}

        start_time = time.time()
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')

        angle_threshold = self.angle / 180 * math.pi
        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        
        valid_edges = [e for e in bm.edges if len(e.link_faces) == 2]
        checkedges = set(valid_edges)
        resultedges = []
        result_loops = []
        
        while checkedges:
            e = next(iter(checkedges))
            es = get_loop(bm, e)
            checkedges.difference_update(es)
            
            if len(es) == 0 or len(es) < self.min_loop_length:
                continue
            
            if has_complex_topology(es):
                continue
                
            if self.preserve_boundary_loops:
                preserve = False
                for e in es:
                    for v in e.verts:
                        for edge in v.link_edges:
                            if edge != e and len(edge.link_faces) == 2:
                                try:
                                    if edge.calc_face_angle() > 0.7:
                                        preserve = True
                                        break
                                except ValueError:
                                    continue
                        if preserve: break
                    if preserve: break
                if preserve: continue
            
            if not check_angles(es, angle_threshold):
                continue
                
            resultedges.extend(es)
            loop = edgeloop()
            loop.edges = es
            result_loops.append(loop)
        
        if not result_loops:
            self.report({'INFO'}, "No redundant edge loops found to clean")
            bpy.ops.object.mode_set(mode='OBJECT')
            return {'FINISHED'}
        
        for l in result_loops:
            for e in l.edges:
                e.select = True
        
        bmesh.update_edit_mesh(obj.data)
        bpy.ops.mesh.dissolve_edges()
        
        if self.triangulate:
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
            bpy.ops.mesh.tris_convert_to_quads()
        
        bpy.ops.object.mode_set(mode='OBJECT')
        
        decimate_mod = get_modifier(obj, 'DECIMATE')
        if decimate_mod:
            try:
                decimate_name = decimate_mod.name
                bpy.ops.object.modifier_apply(modifier=decimate_name)
                self.report({'INFO'}, "Applied Decimate modifier")
            except Exception as e:
                self.report({'WARNING'}, f"Couldn't apply Decimate modifier: {str(e)}")
        
        weighted_normal = obj.modifiers.new(name="WeightedNormal", type='WEIGHTED_NORMAL')
        weighted_normal.keep_sharp = True
        
        props.clean_edge_loops_last_angle = self.angle
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        self.report({'INFO'}, f"Cleaned edge loops with {self.angle}° threshold in {execution_time:.2f}s")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        last_angle = context.scene.bqr_props.clean_edge_loops_last_angle
        if last_angle > 0:
            self.angle = last_angle
        return context.window_manager.invoke_props_dialog(self)
        
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "angle")
        layout.prop(self, "preserve_boundary_loops")
        layout.prop(self, "min_loop_length")
        layout.prop(self, "triangulate")

class __xRMH_S(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_remeshit", "RemeshIT", "Apply Remesh + Bevel + Subsurf"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.bqr_props

        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh")
            return {'CANCELLED'}

        if has_modifier_stack(obj, ['REMESH', 'BEVEL', 'SUBSURF']):
            self.report({'WARNING'}, "RemeshIT has already been applied")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        try:
            bpy.ops.mesh.remove_doubles(threshold=0.0001)
        except:
            self.report({'WARNING'}, "Remove Doubles not available in current context")
        bpy.ops.object.mode_set(mode='OBJECT')

        # Create modifiers in reverse order for the stack
        smooth = obj.modifiers.new(name="Smooth", type='SMOOTH')
        smooth.iterations = props.smooth_repeat
        smooth.use_pin_to_last = True

        subsurf = obj.modifiers.new(name="Subdivision", type='SUBSURF')
        subsurf.levels = props.subsurf_level
        subsurf.use_pin_to_last = True

        bevel = obj.modifiers.new(name="Bevel", type='BEVEL')
        bevel.segments = props.bevel_segments
        bevel.miter_outer = 'MITER_ARC' if props.use_beauty_bevel else 'MITER_SHARP'
        bevel.limit_method = 'ANGLE'
        bevel.angle_limit = props.bevel_angle * (math.pi / 180)
        bevel.profile = props.bevel_profile
        bevel.width = props.bevel_amount
        bevel.use_pin_to_last = True

        remesh = obj.modifiers.new(name="Remesh", type='REMESH')
        remesh.mode = 'SHARP'
        remesh.octree_depth = props.remesh_depth
        remesh.scale = props.remesh_scale
        remesh.use_remove_disconnected = False
        remesh.use_smooth_shade = True
        remesh.use_pin_to_last = True
        
        bpy.ops.object.shade_smooth()
        
        # Show wireframe
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.overlay.show_wireframes = True
            
        return {'FINISHED'}

class __xRST_R(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_reset_remesh", "Reset Remesh Settings", "Reset remesh and bevel settings to default"

    def execute(self, context):
        props = context.scene.bqr_props
        props.remesh_depth = 4
        props.remesh_scale = 0.9
        props.bevel_amount = 0.02
        props.bevel_segments = 3
        props.bevel_angle = 30.0
        props.bevel_profile = 0.5
        props.subsurf_level = 1
        self.report({'INFO'}, "Remesh settings reset to default")
        return {'FINISHED'}

class BQR_OT_ToggleAutoSync(bpy.types.Operator):
    bl_idname, bl_label = "object.bqr_toggle_autosync", "Toggle Auto-Sync"

    def execute(self, context):
        context.scene.bqr_autosync_enabled = not context.scene.bqr_autosync_enabled
        return {'FINISHED'}

class BQR_OT_SyncNow(bpy.types.Operator):
    bl_idname, bl_label = "object.bqr_sync_now", "Sync From Modifiers"

    def execute(self, context):
        obj = context.active_object
        props = context.scene.bqr_props

        if obj and obj.type == 'MESH':
            mod = get_modifier(obj, 'REMESH')
            if mod:
                props.remesh_depth = mod.octree_depth
                props.remesh_scale = mod.scale
            mod = get_modifier(obj, 'BEVEL')
            if mod:
                props.bevel_amount = mod.width
                props.bevel_segments = mod.segments
                props.bevel_angle = mod.angle_limit * (180 / math.pi)
                props.bevel_profile = mod.profile
                props.use_beauty_bevel = (mod.miter_outer == 'MITER_ARC')
            mod = get_modifier(obj, 'SUBSURF')
            if mod:
                props.subsurf_level = mod.levels
            mod = get_modifier(obj, 'SMOOTH')
            if mod:
                props.smooth_repeat = mod.iterations
            mod = get_modifier(obj, 'DECIMATE')
            if mod:
                props.decimate_iterations = mod.iterations

        return {'FINISHED'}

class __xPNL_P(bpy.types.Panel):
    @classmethod
    def poll(cls, context): return context.object is not None and context.object.type == 'MESH'
    bl_label, bl_idname = "Boolean Quad Ready (BQR)", "BQR_PT_panel"
    bl_space_type, bl_region_type, bl_category = 'VIEW_3D', 'UI', 'BQR'

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator("object.bqr_toggle_autosync", text="🔁 Auto-Synch", depress=context.scene.bqr_autosync_enabled)
        row.operator("object.bqr_sync_now", text="🔄 Sync")
        
        layout = self.layout
        obj = context.active_object
        layout.use_property_split = True
        layout.use_property_decorate = False
        props = context.scene.bqr_props

        # Main Workflow Box
        box_main = layout.box()
        box_main.prop(context.scene, "show_main", text="⚙️ Main Workflow", toggle=True, 
                      icon='TRIA_DOWN' if getattr(context.scene, 'show_main', True) else 'TRIA_RIGHT')
        box_main.operator("object.bqr_remeshit", text="RemeshIT", icon='MOD_REMESH')

        if obj and obj.type == 'MESH' and has_modifier_stack(obj, ['REMESH', 'BEVEL', 'SUBSURF']) and context.scene.show_main:
            depsgraph = context.evaluated_depsgraph_get()
            eval_obj = obj.evaluated_get(depsgraph)
            tris = sum(len(p.vertices) - 2 if len(p.vertices) > 2 else 1 for p in eval_obj.data.polygons)
            box_main.label(text=f"🧮 Triangle Count: {tris}")
            box_main.label(text="⚠️ BQR it's still in BETA", icon='INFO')
            box_main.prop(props, "remesh_depth")
            box_main.prop(props, "remesh_scale")
            box_main.prop(props, "bevel_amount")
            box_main.prop(props, "bevel_segments")
            box_main.prop(props, "bevel_angle")
            box_main.prop(props, "bevel_profile")
            box_main.prop(props, "subsurf_level")
            box_main.operator("object.bqr_reset_remesh", icon='LOOP_BACK')
            if has_modifier_stack(obj, ['REMESH', 'BEVEL', 'SUBSURF']):
                box_main.operator("object.bqr_clear_modifiers", icon='PANEL_CLOSE')

        layout.separator()

        # Refining Box
        box_smooth = layout.box()
        box_smooth.prop(context.scene, "show_smooth", text="🔧 Refining", toggle=True, 
                       icon='TRIA_DOWN' if getattr(context.scene, 'show_smooth', True) else 'TRIA_RIGHT')
        if context.scene.show_smooth:
            box_smooth.prop(props, "smooth_repeat")
            box_smooth.prop(props, "use_beauty_bevel")

        layout.separator()
        
        # Modeling Box
        box_modeling = layout.box()
        box_modeling.prop(context.scene, "show_modeling", text="🔨 Modeling", toggle=True,
                        icon='TRIA_DOWN' if getattr(context.scene, 'show_modeling', False) else 'TRIA_RIGHT')
        if context.scene.show_modeling:
            # Mirror toggle button
            row = box_modeling.row()
            row.prop(props, "use_mirror", text="Mirror", toggle=True, icon='MOD_MIRROR')
            
            # Mirror settings sub-panel (only shown when Mirror is active)
            if props.use_mirror and get_modifier(obj, 'MIRROR'):
                box_mirror = box_modeling.box()
                
                # Axis selection
                row = box_mirror.row(align=True)
                row.label(text="Axis:")
                row.prop(props, "mirror_use_axis_x", toggle=True)
                row.prop(props, "mirror_use_axis_y", toggle=True)
                row.prop(props, "mirror_use_axis_z", toggle=True)
                
                # Mirror object
                box_mirror.prop(props, "mirror_object")
                
                # Merge and clip
                row = box_mirror.row(align=True)
                row.prop(props, "mirror_use_merge", toggle=True)
                row.prop(props, "mirror_use_clip", toggle=True)
                
                # Move Mirror Up/Down buttons
                row = box_mirror.row(align=True)
                row.operator("object.bqr_move_mirror_up", icon='TRIA_UP')
                row.operator("object.bqr_move_mirror_down", icon='TRIA_DOWN')

        layout.separator()

        # Finalization Box
        box_finalize = layout.box()
        box_finalize.prop(context.scene, "show_finalize", text="🛠️ Finalization", toggle=True, 
                         icon='TRIA_DOWN' if getattr(context.scene, 'show_finalize', True) else 'TRIA_RIGHT')
        
        if context.scene.show_finalize:
            box_finalize.operator("object.bqr_apply_all", icon='CHECKMARK')
            box_finalize.operator("object.bqr_optimize", icon='MOD_DECIM')
            box_finalize.operator("object.bqr_clean_loops", icon='MESH_DATA')
            box_finalize.operator("object.bqr_uv_unwrap", icon='GROUP_UVS')

        # Version label
        layout.label(text=f"BQR Version {bl_info['version'][0]}.{bl_info['version'][1]}", icon='INFO')

# Mirror move operator
class __xMRR_M(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_move_mirror_up", "Move Mirror Up", "Move mirror to the top of the stack"

    def execute(self, context):
        obj = context.active_object
        mirror = get_modifier(obj, 'MIRROR')
        
        if mirror:
            # Unpin the mirror so it can be moved
            mirror.use_pin_to_last = False
            # Move to index 0 (top of stack)
            bpy.ops.object.modifier_move_to_index(modifier=mirror.name, index=0)
            
        return {'FINISHED'}

# Mirror move down operator
class __xMRR_D(bpy.types.Operator):
    bl_idname, bl_label, bl_description = "object.bqr_move_mirror_down", "Move Mirror Down", "Move mirror to the bottom of the stack and pin it"

    def execute(self, context):
        obj = context.active_object
        mirror = get_modifier(obj, 'MIRROR')
        
        if mirror:
            # Pin the mirror
            mirror.use_pin_to_last = True
            # Move to the end of the stack
            bpy.ops.object.modifier_move_to_index(modifier=mirror.name, index=len(obj.modifiers)-1)
            
        return {'FINISHED'}

# === Registration ===
classes = [
    BQR_OT_ToggleAutoSync, BQR_OT_SyncNow, BQRProperties,
    __xRMH_S, __xAPL_A, __xOPT_M, __xUV_W, __xCLN_L, __xRST_R, __xCLR_M, __xMRR_M, __xMRR_D, __xPNL_P,
]

def update_bqr_props_on_selection(scene, depsgraph):
    if not bpy.context.scene.get('bqr_autosync_enabled', False): return
    obj = bpy.context.active_object
    props = bpy.context.scene.bqr_props

    if obj and obj.type == 'MESH':
        # Sync properties from modifiers
        for mod_type, props_map in {
            'REMESH': [('octree_depth', 'remesh_depth'), ('scale', 'remesh_scale')],
            'BEVEL': [('width', 'bevel_amount'), ('segments', 'bevel_segments'), 
                     ('angle_limit', 'bevel_angle', lambda x: x * (180 / math.pi)), 
                     ('profile', 'bevel_profile')],
            'SUBSURF': [('levels', 'subsurf_level')],
            'SMOOTH': [('iterations', 'smooth_repeat')],
            'DECIMATE': [('iterations', 'decimate_iterations')],
            'MIRROR': [('use_mirror_merge', 'mirror_use_merge'), ('use_clip', 'mirror_use_clip')]
        }.items():
            mod = get_modifier(obj, mod_type)
            if mod:
                for item in props_map:
                    if len(item) == 2:
                        mod_attr, prop_attr = item
                        setattr(props, prop_attr, getattr(mod, mod_attr))
                    else:
                        mod_attr, prop_attr, transform = item
                        setattr(props, prop_attr, transform(getattr(mod, mod_attr)))
                
                # Special cases for specific modifiers
                if mod_type == 'BEVEL':
                    props.use_beauty_bevel = (mod.miter_outer == 'MITER_ARC')
                elif mod_type == 'MIRROR':
                    # Update mirror toggle based on viewport visibility
                    props.use_mirror = mod.show_viewport
                    props.mirror_use_axis_x = mod.use_axis[0]
                    props.mirror_use_axis_y = mod.use_axis[1]
                    props.mirror_use_axis_z = mod.use_axis[2]
                    props.mirror_object = mod.mirror_object
        
        # Update mirror toggle state if no mirror modifier exists
        if not get_modifier(obj, 'MIRROR'):
            props.use_mirror = False

def register():
    bpy.app.handlers.depsgraph_update_post.append(update_bqr_props_on_selection)
    bpy.types.Scene.bqr_autosync_enabled = bpy.props.BoolProperty(default=False, name="Auto-Synch Enabled")
    bpy.types.Scene.show_main = bpy.props.BoolProperty(name="Show Main", default=True)
    bpy.types.Scene.show_smooth = bpy.props.BoolProperty(name="Show Smooth", default=True)
    bpy.types.Scene.show_modeling = bpy.props.BoolProperty(name="Show Modeling", default=False)
    bpy.types.Scene.show_finalize = bpy.props.BoolProperty(name="Show Finalize", default=True)
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Scene.bqr_props = PointerProperty(type=BQRProperties)

def unregister():
    if update_bqr_props_on_selection in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(update_bqr_props_on_selection)
    del bpy.types.Scene.bqr_autosync_enabled
    del bpy.types.Scene.show_main
    del bpy.types.Scene.show_smooth
    del bpy.types.Scene.show_modeling
    del bpy.types.Scene.show_finalize
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
    del bpy.types.Scene.bqr_props

if __name__ == "__main__": register()