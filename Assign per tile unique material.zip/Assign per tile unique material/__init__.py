bl_info = {
    "name": "Process Per Tile Materials",
    "blender": (4, 2, 0),
    "category": "Export File",
    "author": "Tech Boy JaTiX",
    "version": (1, 2, 0),
    "description": "Assign per tile unique material based on UDIM tiles with sequential processing",
}

import bpy

class PROCESS_OT_Materials(bpy.types.Operator):
    """Operator to process materials and rename single-tile materials with UDIM suffix"""
    bl_idname = "object.process_materials"
    bl_label = "Process Per Tile Materials"
    bl_description = "Create unique materials for each UDIM tile and rename single-tile materials"
    
    def execute(self, context):
        try:
            processed_materials = process_materials()
            if processed_materials:
                delete_original_materials(processed_materials)
                self.report({'INFO'}, f"Successfully processed {len(processed_materials)} materials")
            else:
                self.report({'WARNING'}, "No materials needed processing")
        except Exception as e:
            self.report({'ERROR'}, f"Error processing materials: {str(e)}")
            return {'CANCELLED'}
        
        return {'FINISHED'}


def get_uv_tile_count(obj):
    """Determine the UV tiles (UDIMs) used by the object."""
    if not obj.data.uv_layers.active:
        return set()
    
    uv_layer = obj.data.uv_layers.active
    uv_tiles = set()
    
    for poly in obj.data.polygons:
        for loop_index in poly.loop_indices:
            if loop_index < len(uv_layer.data):
                uv = uv_layer.data[loop_index].uv
                # Calculate tile coordinates by flooring UV coordinates
                tile_x = int(uv.x)
                tile_y = int(uv.y)
                uv_tiles.add((tile_x, tile_y))
    
    return uv_tiles


def get_udim_tile_index(tile_coord):
    """Calculate UDIM tile index from tile coordinates (1001, 1002, etc.)"""
    tile_x, tile_y = tile_coord
    return 1001 + tile_x + (tile_y * 10)


def sort_tile_coords_by_udim(tile_coords):
    """Sort tile coordinates in UDIM order: 1001-1010, 1011-1020, etc."""
    # Convert to list of (tile_coord, udim_index) tuples
    tile_udim_pairs = [(coord, get_udim_tile_index(coord)) for coord in tile_coords]
    
    # Sort by UDIM index
    tile_udim_pairs.sort(key=lambda x: x[1])
    
    # Extract just the sorted coordinates
    return [pair[0] for pair in tile_udim_pairs]


def get_material_tile_coord(obj, material):
    """Get the primary tile coordinate for a material used in an object."""
    if not obj.data.uv_layers.active:
        return (0, 0)
    
    uv_layer = obj.data.uv_layers.active
    tile_coords = []
    
    # Find all polygons using this material
    for poly in obj.data.polygons:
        if poly.material_index < len(obj.material_slots):
            slot_material = obj.material_slots[poly.material_index].material
            if slot_material == material:
                # Get UV coordinate from first loop of polygon
                if poly.loop_indices:
                    loop_index = poly.loop_indices[0]
                    if loop_index < len(uv_layer.data):
                        uv = uv_layer.data[loop_index].uv
                        tile_x = int(uv.x)
                        tile_y = int(uv.y)
                        tile_coords.append((tile_x, tile_y))
    
    # Return the most common tile coordinate, or (0,0) if none found
    if tile_coords:
        # Count frequency of each tile coordinate
        from collections import Counter
        counter = Counter(tile_coords)
        return counter.most_common(1)[0][0]
    
    return (0, 0)


def duplicate_material_for_tiles(original_material, tile_coords):
    """Duplicate material for each tile coordinate with UDIM naming, processing in UDIM order."""
    duplicated_materials = []
    
    # Sort tiles in UDIM order: 1001-1010, 1011-1020, etc.
    sorted_tile_coords = sort_tile_coords_by_udim(tile_coords)
    
    print(f"Processing tiles in order: {[get_udim_tile_index(coord) for coord in sorted_tile_coords]}")
    
    for tile_coord in sorted_tile_coords:
        new_mat = original_material.copy()
        udim_index = get_udim_tile_index(tile_coord)
        new_mat.name = f"{original_material.name}_{udim_index}"
        duplicated_materials.append((tile_coord, new_mat))
        
        # Print progress for large tile sets
        if len(sorted_tile_coords) > 10:
            print(f"Created material for UDIM {udim_index}")
    
    return duplicated_materials


def rename_single_tile_material(material, tile_coord):
    """Rename a material used in a single tile with UDIM suffix."""
    udim_index = get_udim_tile_index(tile_coord)
    new_name = f"{material.name}_{udim_index}"
    
    # Check if name already exists to avoid conflicts
    if new_name not in bpy.data.materials:
        material.name = new_name
        print(f"Renamed single-tile material: {material.name} (UDIM {udim_index})")
        return True
    else:
        print(f"Warning: Material name {new_name} already exists, keeping original name")
        return False


def process_materials():
    """Process all materials in the scene for UDIM tile separation with proper ordering."""
    processed_materials = []
    
    # Process each material that isn't already a tile material
    for material in bpy.data.materials:
        # Skip materials that are already processed (have UDIM suffix)
        material_name_parts = material.name.split("_")
        if material_name_parts and material_name_parts[-1].isdigit():
            udim_suffix = int(material_name_parts[-1])
            if 1001 <= udim_suffix <= 2000:  # Reasonable UDIM range
                print(f"Skipping already processed material: {material.name}")
                continue
            
        print(f"\n=== Processing material: {material.name} ===")
        
        # Find all mesh objects using this material
        linked_objects = []
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                for slot in obj.material_slots:
                    if slot.material == material:
                        linked_objects.append(obj)
                        break
        
        if not linked_objects:
            print(f"No objects linked to {material.name}, skipping")
            continue

        # Get all unique UV tiles across all linked objects
        all_uv_tiles = set()
        for obj in linked_objects:
            obj_tiles = get_uv_tile_count(obj)
            if obj_tiles:
                all_uv_tiles.update(obj_tiles)
        
        uv_tile_count = len(all_uv_tiles)
        udim_indices = [get_udim_tile_index(coord) for coord in all_uv_tiles]
        print(f"Found {uv_tile_count} UV tiles for material '{material.name}': {sorted(udim_indices)}")
        
        # Handle single tile materials - rename with UDIM suffix
        if uv_tile_count == 1:
            tile_coord = next(iter(all_uv_tiles))
            if rename_single_tile_material(material, tile_coord):
                processed_materials.append(material.name)
                print(f"Renamed single-tile material {material.name} with UDIM suffix")
            continue
        
        # Skip materials with no UV tiles
        if uv_tile_count == 0:
            print(f"Skipping material {material.name} - no UV tiles found")
            continue
        
        # Handle multiple tile materials - duplicate and assign
        # Create mapping from tile coordinates to material indices
        tile_to_mat_index = {}
        
        # Duplicate materials for each tile (now in UDIM order)
        tile_materials = duplicate_material_for_tiles(material, all_uv_tiles)
        
        # Process each linked object
        for obj in linked_objects:
            print(f"Processing object: {obj.name}")
            
            # Store current material assignments for polygons
            original_poly_materials = [poly.material_index for poly in obj.data.polygons]
            
            # Clear and rebuild material slots
            original_material_count = len(obj.material_slots)
            obj.data.materials.clear()
            
            # Add all tile materials to the object in UDIM order
            for tile_coord, tile_mat in tile_materials:
                obj.data.materials.append(tile_mat)
                tile_to_mat_index[tile_coord] = len(obj.data.materials) - 1
            
            # Assign materials to polygons based on UV tiles
            uv_layer = obj.data.uv_layers.active
            if uv_layer:
                assigned_count = 0
                for poly in obj.data.polygons:
                    if poly.loop_indices:
                        loop_index = poly.loop_indices[0]
                        if loop_index < len(uv_layer.data):
                            uv = uv_layer.data[loop_index].uv
                            tile_x = int(uv.x)
                            tile_y = int(uv.y)
                            tile_coord = (tile_x, tile_y)
                            
                            if tile_coord in tile_to_mat_index:
                                poly.material_index = tile_to_mat_index[tile_coord]
                                assigned_count += 1
                            else:
                                # Fallback: use original material index or 0
                                poly.material_index = original_poly_materials[poly.index] if poly.index < len(original_poly_materials) else 0
                
                print(f"Assigned materials to {assigned_count} polygons based on UV tiles")
        
        processed_materials.append(material.name)
        print(f"Successfully processed material: {material.name} -> {len(tile_materials)} tile materials")
    
    return processed_materials


def delete_original_materials(processed_material_names):
    """Delete original materials after processing if they're no longer used."""
    deleted_count = 0
    for mat_name in processed_material_names:
        # Check if the material still exists and has its original name (not renamed)
        if mat_name in bpy.data.materials:
            original_mat = bpy.data.materials[mat_name]
            
            # Skip if the material has been renamed (single tile case)
            if original_mat.name != mat_name:
                continue
                
            # Check if any object still uses the original material
            still_used = False
            for obj in bpy.data.objects:
                if obj.type == 'MESH':
                    for slot in obj.material_slots:
                        if slot.material == original_mat:
                            still_used = True
                            break
                    if still_used:
                        break
            
            if not still_used and original_mat.users == 0:
                print(f"Deleting original material: {mat_name}")
                bpy.data.materials.remove(original_mat)
                deleted_count += 1
            elif still_used:
                print(f"Material {mat_name} still in use, skipping deletion")
            else:
                print(f"Material {mat_name} has {original_mat.users} users, skipping deletion")
    
    print(f"Deleted {deleted_count} original materials")


class VIEW3D_PT_Materials(bpy.types.Panel):
    """Panel for Material Processing Tools"""
    bl_label = "UDIM Material Processor"
    bl_idname = "VIEW3D_PT_Materials"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'

    def draw(self, context):
        layout = self.layout
        
        # Add main button
        layout.operator("object.process_materials", text="Process Per Tile Materials", icon='MATERIAL')


def register():
    bpy.utils.register_class(PROCESS_OT_Materials)
    bpy.utils.register_class(VIEW3D_PT_Materials)


def unregister():
    bpy.utils.unregister_class(PROCESS_OT_Materials)
    bpy.utils.unregister_class(VIEW3D_PT_Materials)


if __name__ == "__main__":
    register()