bl_info = {
    "name": "select overlapping objects",
    "author": "Meet",
    "version": (1, 1),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Item tab",
    "description": "Click on select button for select overlap objects",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

import bpy
import bmesh
from mathutils import Vector, Matrix

def bbox_intersect(bbox1, bbox2):
    for i in range(3):
        if bbox1[0][i] > bbox2[1][i] or bbox2[0][i] > bbox1[1][i]:
            return False
    return True

def select_overlapping_objects():
    # Deselect all objects
    bpy.ops.object.select_all(action='DESELECT')
    
    # Get all mesh objects
    all_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
    
    # Track already selected objects to avoid re-selection
    selected = set()
    
    # Loop through all objects to check for overlaps
    for i, obj1 in enumerate(all_objects):
        if obj1.name in selected:
            continue
        
        bbox1 = [obj1.matrix_world @ Vector(v) for v in obj1.bound_box]

        for j, obj2 in enumerate(all_objects):
            if i >= j:
                continue
            bbox2 = [obj2.matrix_world @ Vector(v) for v in obj2.bound_box]
            
            # Check intersection
            if bbox_intersect(bbox1, bbox2):
                obj1.select_set(True)
                selected.add(obj1.name)
                break  # Only select the first overlapping mesh

class OBJECT_OT_select_overlapping(bpy.types.Operator):
    """Select Overlapping Objects"""
    bl_idname = "object.select_overlapping"
    bl_label = "Select"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        select_overlapping_objects()
        return {'FINISHED'}

class VIEW3D_PT_select_overlapping(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "select overlap objects"
    bl_idname = "VIEW3D_PT_select_overlapping"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tool'
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.select_overlapping")

def register():
    bpy.utils.register_class(OBJECT_OT_select_overlapping)
    bpy.utils.register_class(VIEW3D_PT_select_overlapping)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_select_overlapping)
    bpy.utils.unregister_class(VIEW3D_PT_select_overlapping)

if __name__ == "__main__":
    register()
