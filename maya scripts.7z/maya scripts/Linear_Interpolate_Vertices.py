import maya.cmds as cmds

cmds.SelectEdgeLoopSp()

def linear_interpolate_vertices():
    # Get the current selection
    selected_vertices = cmds.ls(selection=True, flatten=True)

    if len(selected_vertices) < 2:
        cmds.error("Please select at least two vertices.")
        return

    # Get the positions of the first and last selected vertices
    first_vertex_pos = cmds.pointPosition(selected_vertices[0])
    last_vertex_pos = cmds.pointPosition(selected_vertices[-1])

    num_selected = len(selected_vertices)

    for i in range(1, num_selected - 1):
        t = i / (num_selected - 1.0)
        interpolated_pos = [
            first_vertex_pos[0] * (1 - t) + last_vertex_pos[0] * t,
            first_vertex_pos[1] * (1 - t) + last_vertex_pos[1] * t,
            first_vertex_pos[2] * (1 - t) + last_vertex_pos[2] * t
        ]
        
        # Move the in-between vertex to the interpolated position
        cmds.xform(selected_vertices[i], worldSpace=True, translation=interpolated_pos)
        cmds.select(clear=True)

# Run the function
linear_interpolate_vertices()