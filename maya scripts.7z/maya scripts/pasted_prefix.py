PasteSelected;
searchReplaceNames "pasted__" "0" "all";