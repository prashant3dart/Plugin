import maya.cmds as cmds
import maya.mel as mel

def get_bounding_box(mesh):
    """
    Get the bounding box of a given mesh.
    """
    bounding_box = cmds.exactWorldBoundingBox(mesh)
    return bounding_box

def is_overlapping(box1, box2):
    """
    Check if two bounding boxes are overlapping.
    """
    overlap_x = box1[0] <= box2[3] and box1[3] >= box2[0]
    overlap_y = box1[1] <= box2[4] and box1[4] >= box2[1]
    overlap_z = box1[2] <= box2[5] and box1[5] >= box2[2]
    return overlap_x and overlap_y and overlap_z

def select_unique_overlapping_meshes():
    """
    Select one unique mesh from each overlapping pair.
    """
    all_meshes = cmds.ls(type="mesh", long=True)
    mesh_transforms = cmds.listRelatives(all_meshes, parent=True, fullPath=True)
    
    selected_meshes = set()
    
    for i, mesh1 in enumerate(mesh_transforms):
        bbox1 = get_bounding_box(mesh1)
        for j, mesh2 in enumerate(mesh_transforms[i+1:], start=i+1):
            bbox2 = get_bounding_box(mesh2)
            if is_overlapping(bbox1, bbox2):
                selected_meshes.add(mesh1)
                break  # Move to the next mesh1 as soon as we find an overlap
    
    if selected_meshes:
        cmds.select(list(selected_meshes))
    else:
        cmds.select(clear=True)
        print("No overlapping meshes found.")

# Run the function
select_unique_overlapping_meshes()
